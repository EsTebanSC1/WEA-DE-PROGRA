
package test;

import Main.LoR;

/*
Bastian Alejandro Fuentes
Maria Jose Pangui 
Claudio Vidal
Esteban Daniel Seron Correa

*/

public class Main {

  
    public static void main(String[] args) {
        LoR lor1 = new LoR();
        lor1.setVisible(true);
    }
    
}
